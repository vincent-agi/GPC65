/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Link } from "../router";
import { Breadcrumbs } from "../components/Breadcrumbs";
import { Landmark, Compass, Award, Shield, Users, ArrowRight, Heart } from "lucide-react";
import { motion } from "motion/react";

export const About: React.FC = () => {
  const team = [
    {
      name: "Jean-Pierre Sere",
      role: "President & Historical Architect",
      bio: "With over 30 years in masonry restoration, Jean-Pierre leads our architectural preservation projects and dry-stone pointing workshops in the Aure Valley.",
      initials: "JS"
    },
    {
      name: "Dr. Clara Montagne",
      role: "Lead Archaeologist & Researcher",
      bio: "Dr. Montagne has overseen major Pyrenean excavations, focusing on Gallo-Roman thermal bath systems and medieval trade junctions.",
      initials: "CM"
    },
    {
      name: "Marie-Amélie Larrouy",
      role: "Director of Cultural Outreach",
      bio: "A native of Cadéac, Marie-Amélie leads our oral history interviews with senior citizens and teaches Pyrenean loom-weaving techniques.",
      initials: "ML"
    }
  ];

  const milestones = [
    { year: "1985", title: "Foundation", desc: "A handful of local volunteers set up GPC65 to prevent the demolition of the old municipal flour mill." },
    { year: "1998", title: "The Romanesque Survey", desc: "Our research team completed the first digital and architectural inventory of Romanesque chapels in the valley." },
    { year: "2012", title: "Oral Archives Launch", desc: "Began systematic audio recording of senior shepherds, preserving priceless Pyrenean linguistic and agricultural memories." },
    { year: "2026", title: "Medieval Watchtower Campaign", desc: "Initiated our largest structural campaign to secure and point the 12th-century tower of Cadéac." }
  ];

  return (
    <div id="about-association-page" className="w-full bg-white">
      <Breadcrumbs items={[{ label: "About GPC65" }]} />

      {/* Hero Banner Section */}
      <section className="relative bg-slate-900 text-white py-16 sm:py-20 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&w=1200&q=80"
            alt="Old stone French village streets"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-xs font-bold font-display uppercase tracking-widest text-blue-400 block mb-3">
            WHO WE ARE & WHAT WE PROTECT
          </span>
          <h1 className="font-display font-extrabold text-3xl sm:text-4xl md:text-5xl text-white tracking-tight leading-tight">
            Preserving the Soul of the Pyrenean Valleys
          </h1>
          <p className="text-slate-300 mt-4 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            The GPC65 Cultural Heritage Association is a non-profit group of researchers, local residents, and craft enthusiasts working in Cadéac to defend regional history.
          </p>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-slate-900 tracking-tight mb-6">
              Our Unwavering Mission
            </h2>
            <div className="space-y-6 text-sm sm:text-base text-slate-600 leading-relaxed">
              <p>
                Founded in 1985 in the picturesque mountain village of Cadéac, GPC65 was born out of a critical need to safeguard crumbling Romanesque chapels, high altitude watchtowers, and agricultural trails. We believe that physical structures and oral traditions are the twin pillars of cultural identity.
              </p>
              <p>
                By working in close cooperation with municipal councils, architectural historians, and passionate volunteers, we conduct scientific research, organize physical pointing campaigns, and maintain a modern digital archive of the valley&apos;s history.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="flex gap-2.5 items-start">
                <Shield className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Strict Honesty</h4>
                  <p className="text-xs text-slate-500 mt-1">Sourcing materials locally and utilizing age-old techniques.</p>
                </div>
              </div>
              <div className="flex gap-2.5 items-start">
                <Users className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Open Community</h4>
                  <p className="text-xs text-slate-500 mt-1">Inviting public participation in every research and masonry phase.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-3xl overflow-hidden bg-slate-100 border border-slate-100 shadow-md">
              <img
                src="https://images.unsplash.com/photo-1599827551410-b9dfba366fb5?auto=format&fit=crop&w=800&q=80"
                alt="Preservation masonry work"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-blue-600 text-white rounded-2xl p-6 shadow-xl hidden sm:block max-w-[240px]">
              <Award className="h-8 w-8 text-blue-200 mb-2" />
              <h4 className="font-display font-bold text-base">State Heritage Prize</h4>
              <p className="text-xs text-blue-100 mt-1">Awarded in 2024 for architectural preservation in Occitanie.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16 sm:py-20 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-slate-900 tracking-tight">
              Our Journey of Preservation
            </h2>
            <p className="text-sm text-slate-500 mt-2 leading-relaxed">
              Forty years of volunteer-led historical mapping and conservation campaigns.
            </p>
          </div>

          <div className="relative border-l-2 border-slate-200 max-w-3xl mx-auto pl-6 sm:pl-8 space-y-10">
            {milestones.map((m, index) => (
              <div key={index} className="relative">
                <div className="absolute -left-[31px] sm:-left-[39px] top-1 h-5 w-5 rounded-full border-4 border-white bg-blue-600 shadow-sm" />
                <span className="font-display font-black text-xl text-blue-600 leading-none">
                  {m.year}
                </span>
                <h3 className="font-display font-bold text-base text-slate-900 mt-1 mb-2">
                  {m.title}
                </h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  {m.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Board Grid */}
      <section className="py-16 sm:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-slate-900 tracking-tight">
            Our Research & Project Leads
          </h2>
          <p className="text-sm text-slate-500 mt-2 leading-relaxed">
            Leading field studies, architectural diagnostics, and community classes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {team.map((t, index) => (
            <div key={index} className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex flex-col items-center text-center">
              <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-blue-700 to-blue-900 text-white font-display font-black text-xl flex items-center justify-center shadow-inner mb-4">
                {t.initials}
              </div>
              <h3 className="font-display font-bold text-base text-slate-900 mb-1">
                {t.name}
              </h3>
              <span className="text-xs font-bold font-display text-blue-600 uppercase tracking-wide block mb-3">
                {t.role}
              </span>
              <p className="text-xs text-slate-500 leading-relaxed">
                {t.bio}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Support Us Banner */}
      <section className="bg-slate-950 text-white py-16 relative overflow-hidden border-t border-slate-800">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Heart className="h-10 w-10 text-rose-500 mx-auto mb-4 animate-pulse" />
          <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
            Support Our Preservation Efforts
          </h2>
          <p className="text-slate-400 mt-3 text-sm leading-relaxed max-w-xl mx-auto">
            Your generous contributions directly fund regional lime supplies, safety scaffolding, research publications, and free public archives.
          </p>
          <div className="mt-8 flex justify-center gap-4">
            <Link
              to="/contact"
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-display font-bold text-sm rounded-xl transition-all shadow-md focus:outline-none"
            >
              Contact Us to Join
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
