/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WPPost, WPCategory, WPTag, SimplifiedPost } from "./types";

const WP_API_BASE = "https://gpc65-gestion.cazu1740.odns.fr/wp-json/wp/v2";

// Seed/Fallback Data
export const SEED_CATEGORIES: WPCategory[] = [
  {
    id: 1,
    count: 5,
    description: "Preserving historical landmarks, defense towers, and architectural integrity in the Pyrenean valley of Cadéac.",
    link: "/category/preservation",
    name: "Heritage Preservation",
    slug: "preservation",
    taxonomy: "category",
    parent: 0,
  },
  {
    id: 2,
    count: 3,
    description: "Explorations, thermal bath excavations, and scientific digs revealing the deep historical layers of the valley.",
    link: "/category/archaeology",
    name: "Archaeology",
    slug: "archaeology",
    taxonomy: "category",
    parent: 0,
  },
  {
    id: 3,
    count: 2,
    description: "Teaching and celebrating regional traditions, Pyrenean hand-weaving, and summer solstice celebrations.",
    link: "/category/culture",
    name: "Culture & Art",
    slug: "culture",
    taxonomy: "category",
    parent: 0,
  },
  {
    id: 4,
    count: 2,
    description: "Annual heritage symposiums, citizen-led workshops, and public digital mapping projects.",
    link: "/category/community",
    name: "Community",
    slug: "community",
    taxonomy: "category",
    parent: 0,
  },
];

export const SEED_TAGS: WPTag[] = [
  { id: 10, count: 2, description: "Watchtower and defense structures", link: "/tag/watchtower", name: "Watchtower", slug: "watchtower", taxonomy: "post_tag" },
  { id: 11, count: 2, description: "Romanesque and medieval architectural style", link: "/tag/romanesque", name: "Romanesque", slug: "romanesque", taxonomy: "post_tag" },
  { id: 12, count: 1, description: "Traditional wool and loom weaving", link: "/tag/weaving", name: "Weaving", slug: "weaving", taxonomy: "post_tag" },
  { id: 13, count: 1, description: "GPS and laser telemetry tools", link: "/tag/mapping", name: "Digital Mapping", slug: "mapping", taxonomy: "post_tag" },
  { id: 14, count: 1, description: "Traditional mountain midsummer fires", link: "/tag/solstice", name: "Solstice", slug: "solstice", taxonomy: "post_tag" },
  { id: 15, count: 2, description: "Dry-stone walls and high paths maintenance", link: "/tag/stone", name: "Dry-stone", slug: "stone", taxonomy: "post_tag" },
];

export const SEED_POSTS: WPPost[] = [
  {
    id: 101,
    date: "2026-06-15T14:30:00",
    slug: "restoring-the-medieval-watchtower",
    title: { rendered: "Restoring the Medieval Watchtower of Cadéac" },
    excerpt: { rendered: "<p>Our latest preservation effort focuses on the structural integrity of the main tower, a 12th-century Romanesque marvel standing guard over the Aure Valley.</p>" },
    content: {
      rendered: `
        <p>The GPC65 Cultural Heritage Association is thrilled to announce the official commencement of restoration works on the <strong>Medieval Watchtower of Cadéac</strong>. This iconic 12th-century structure, perched strategically on a rocky spur overlooking the Aure Valley, has stood for over eight centuries as a symbol of regional defense and architectural mastery.</p>
        
        <h3>A Century of Exposure</h3>
        <p>Years of extreme mountain weather, frost-wedging in mortar joints, and vegetation overgrowth have taken a severe toll on the upper battlements. The south-facing stone facade has shown alarming signs of shifting, endangering both the integrity of the watchtower and the safety of hikers on the trails below.</p>
        
        <blockquote>
          "Our mission is to ensure that this watchtower remains a proud beacon of our history for another eight hundred years. Every stone is a letter in the story of Cadéac."
          <cite>— Jean-Pierre Sere, Lead Historical Architect</cite>
        </blockquote>

        <h3>Preservation Techniques Applied</h3>
        <p>Working closely with regional historical preservation experts, the GPC65 team is employing traditional techniques to preserve historical accuracy:</p>
        <ul>
          <li><strong>Local Lime Mortar:</strong> We are using a custom-blended hydraulic lime mortar matching the exact chemical signature of the 12th-century binder.</li>
          <li><strong>Surgical Stone Splitting:</strong> Damaged slate and limestone blocks are being replaced with stones hand-quarried from nearby Pyrenean cliffs.</li>
          <li><strong>Structural Bracing:</strong> Internal steel rods are being carefully threaded through existing voids to stabilize the tower's foundation without altering its external silhouette.</li>
        </ul>

        <h3>How You Can Participate</h3>
        <p>This project is funded through generous regional grants and personal donations. Volunteers are invited to participate in weekend masonry workshops starting next month. No previous experience is necessary, as our master stonemasons will guide you through the process of traditional pointing and structural masonry.</p>
      `
    },
    author: 1,
    featured_media: 201,
    categories: [1],
    tags: [10, 11],
    _embedded: {
      author: [{ id: 1, name: "Jean-Pierre Sere" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1599827551410-b9dfba366fb5?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Medieval watchtower stone structure in the mountains"
      }],
      'wp:term': [[
        { id: 1, name: "Heritage Preservation", slug: "preservation", taxonomy: "category" }
      ], [
        { id: 10, name: "Watchtower", slug: "watchtower", taxonomy: "post_tag" },
        { id: 11, name: "Romanesque", slug: "romanesque", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 102,
    date: "2026-05-28T09:15:00",
    slug: "excavations-near-the-thermal-baths",
    title: { rendered: "Archaeological Excavations Near the Thermal Baths" },
    excerpt: { rendered: "<p>New archaeological findings suggest the thermal springs of Cadéac were used extensively long before the modern facilities were built.</p>" },
    content: {
      rendered: `
        <p>Recent exploratory digs carried out by the GPC65 Archaeology Unit near the historical thermal springs of Cadéac have yielded extraordinary results. The project, initiated to assess the ground before a municipal drainage upgrade, has uncovered a series of ancient stone channels and brick foundations dating back to the late Gallo-Roman period.</p>
        
        <h3>Unearthing Pyrenean Antiquity</h3>
        <p>The presence of warm sulfur springs in Cadéac has been documented for centuries, but their prehistoric and classical use remained mostly conjectural. During our excavation, we discovered:</p>
        <ul>
          <li><strong>Terracotta Hypocaust Bricks:</strong> Proof of a sophisticated Roman underfloor heating system, typical of private bathhouses.</li>
          <li><strong>Votive Offerings:</strong> Several bronze coins bearing the likeness of Emperor Gratian (circa 375 AD) and miniature carved stone altars dedicated to local mountain deities.</li>
          <li><strong>Timber Water Pipes:</strong> Remarkably preserved pine trunks, hollowed out and joined with iron collars, used to route thermal waters from the spring source.</li>
        </ul>

        <blockquote>
          "This discovery changes our understanding of Roman transport and leisure in the high valleys. It proves Cadéac was a key resting point on the Pyrenean crossing routes."
          <cite>— Dr. Clara Montagne, Archaeologist</cite>
        </blockquote>

        <h3>Preservation and Display Plans</h3>
        <p>The excavated area is currently being surveyed using high-resolution 3D photogrammetry. The GPC65 Association is working on a proposal to establish a permanent glass-covered outdoor viewing deck, allowing residents and tourists to appreciate these ancient engineering achievements in situ.</p>
      `
    },
    author: 2,
    featured_media: 202,
    categories: [2],
    tags: [11],
    _embedded: {
      author: [{ id: 2, name: "Dr. Clara Montagne" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1599707367072-cd6ada2bc375?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Ancient stone foundations and roman bath excavations"
      }],
      'wp:term': [[
        { id: 2, name: "Archaeology", slug: "archaeology", taxonomy: "category" }
      ], [
        { id: 11, name: "Romanesque", slug: "romanesque", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 103,
    date: "2026-05-12T11:00:00",
    slug: "remarkable-houses-the-maison-sere",
    title: { rendered: "Remarkable Houses of the Valley: The Maison Sere" },
    excerpt: { rendered: "<p>An in-depth look at one of Cadéac's most architecturally significant private residences, its timber-frame design, and its colorful history.</p>" },
    content: {
      rendered: `
        <p>Nestled in the heart of Cadéac's old quarter stands the <strong>Maison Sere</strong>, a majestic residential dwelling built in 1582. As part of our ongoing "Remarkable Houses" inventory, the GPC65 Cultural Heritage Association has compiled a comprehensive historical and architectural dossier on this masterpiece of Renaissance timber-frame construction.</p>
        
        <h3>Architectural Marvels</h3>
        <p>Maison Sere is an exceptional example of high-altitude Renaissance architecture. Unlike lowland structures, mountain timber-framing required unique adaptations to handle extreme snow loads and seismic shifts:</p>
        <p>The house features an overhanging upper floor (<em>encorbellement</em>), which served a dual purpose: expanding interior living space while protecting the lower limestone walls from melting snow falling from the eaves.</p>
        
        <h3>The Hand of the Artisan</h3>
        <p>One of the house's most celebrated details is the series of carved wooden corbels supporting the upper joists. These sculptures depict whimsical regional folklore, including stylised Pyrenean bears, roaring gargoyles, and floral solar discs known as <em>lauburus</em>, meant to ward off evil spirits.</p>
        
        <p>Our research team recently discovered a hidden merchant ledger in the municipal archives. It reveals that the original owner, Pierre Sere, was a prosperous wool merchant who traded fine Pyrenean fleece with weaving centers in Toulouse and Bordeaux. This explain the extraordinary quality of the timber carvings, executed by Basque craftsmen traveling through the valley.</p>

        <h3>Preserving Private Heritage</h3>
        <p>Because Maison Sere remains a privately owned home, GPC65 is partnering with the owners to provide maintenance advice and facilitate specialized grants for roof shingle restoration. We believe that preserving living, breathing private heritage is just as vital as protecting public monuments.</p>
      `
    },
    author: 1,
    featured_media: 203,
    categories: [1],
    tags: [10],
    _embedded: {
      author: [{ id: 1, name: "Jean-Pierre Sere" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1513584684374-8bab748fbf90?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Historical Renaissance timber-frame house in a Pyrenean village"
      }],
      'wp:term': [[
        { id: 1, name: "Heritage Preservation", slug: "preservation", taxonomy: "category" }
      ], [
        { id: 10, name: "Watchtower", slug: "watchtower", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 104,
    date: "2025-10-05T17:00:00",
    slug: "annual-heritage-symposium-2025",
    title: { rendered: "Annual Heritage Symposium: A Resounding Success" },
    excerpt: { rendered: "<p>Over 200 participants joined us to discuss the future of digital archiving, architectural preservation, and local culture in mountain communities.</p>" },
    content: {
      rendered: `
        <p>The GPC65 Association's <strong>Annual Heritage Symposium</strong>, held last weekend at the Cadéac Community Hall, brought together historians, conservationists, technology experts, and passionate locals. The theme of this year's conference, "Memory in the Mountains," addressed how remote valleys can use modern digital tools to preserve fragile historical documents.</p>
        
        <h3>Keynote Speeches & Breakout Sessions</h3>
        <p>The weekend was packed with insightful lectures and hands-on workshops:</p>
        <ul>
          <li><strong>Digital Archiving in Action:</strong> Experts demonstrated how cheap flatbed scanners and cloud storage are helping small hamlets digitize parish records dating back to the 16th century.</li>
          <li><strong>The Oral History Project:</strong> High school students presented their audio recordings of local elders recounting agricultural life in the 1940s, creating an invaluable audio map of the valley.</li>
          <li><strong>Dry-Stone Restoration:</strong> Practical demonstrations along the GR10 trail showed how to construct durable retaining walls without mortar.</li>
        </ul>

        <p>We want to thank all our volunteers, speakers, and sponsors who made this event possible. Plans are already underway for next year's symposium, which will focus on ancient trade and migration routes across the Pyrenees.</p>
      `
    },
    author: 3,
    featured_media: 204,
    categories: [4],
    tags: [13],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Symposium conference with audience and speakers"
      }],
      'wp:term': [[
        { id: 4, name: "Community", slug: "community", taxonomy: "category" }
      ], [
        { id: 13, name: "Digital Mapping", slug: "mapping", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 105,
    date: "2025-09-28T08:00:00",
    slug: "tracing-ancestral-paths-digital-map",
    title: { rendered: "Tracing Ancestral Paths: The GPC65 Digital Map" },
    excerpt: { rendered: "<p>We are proud to unveil our new interactive mapping tool that tracks seasonal sheep migration routes and transhumance paths used for centuries.</p>" },
    content: {
      rendered: `
        <p>For hundreds of years, the rhythm of life in the Pyrenees was dictated by <strong>transhumance</strong>—the seasonal movement of livestock between summer mountain pastures and winter valley floors. To preserve this intangible heritage, the GPC65 Technical Team has launched an innovative <strong>Interactive Digital Map</strong>.</p>
        
        <h3>Reconstructing Ancient Routes</h3>
        <p>Using a combination of historical land registers (<em>cadastres</em>), oral testimonies, and modern GPS mapping, our volunteers have charted over 150 kilometers of traditional drovers' paths (<em>drayes</em>) across the Aure and Louron valleys.</p>
        <p>Users can explore the map to discover historical sheepfolds, drinking troughs, and custom boundary stones carved with sheep marcas. Each point of interest is accompanied by a brief history, audio recordings, and historical photographs where available.</p>

        <h3>Educational Applications</h3>
        <p>We are distributing this interactive tool to local schools to help children connect with their regional roots. By understanding how pastures were allocated and shared, students learn valuable lessons about environmental stewardship and community resource management.</p>
      `
    },
    author: 3,
    featured_media: 205,
    categories: [4],
    tags: [13, 15],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1507111082260-2646d0fe0e8e?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Shepherds walking sheep in a green valley under mountains"
      }],
      'wp:term': [[
        { id: 4, name: "Community", slug: "community", taxonomy: "category" }
      ], [
        { id: 13, name: "Digital Mapping", slug: "mapping", taxonomy: "post_tag" },
        { id: 15, name: "Dry-stone", slug: "stone", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 106,
    date: "2025-09-15T15:00:00",
    slug: "protecting-the-ancient-trails",
    title: { rendered: "Protecting the Ancient Trails and Dry-Stone Walls" },
    excerpt: { rendered: "<p>A new volunteer initiative to maintain the historical dry-stone walls along the high mountain passes has been launched this week.</p>" },
    content: {
      rendered: `
        <p>Dry-stone masonry is one of the oldest human technologies, and in our mountain landscape, it is the literal backbone of agricultural life. The stone walls lining the ancient paths of Cadéac prevent soil erosion, define boundaries, and provide micro-habitats for regional flora and fauna. This week, GPC65 is launching a dedicated <strong>Trail and Wall Protection Initiative</strong>.</p>
        
        <h3>The Art of Dry-Stone</h3>
        <p>Dry-stone walls are constructed without any mortar, relying entirely on the weight, friction, and careful placement of interlocking stones. When properly built, they are highly flexible and permeable, allowing water to drain through without undermining the wall's structure—making them far superior to concrete in wet, freezing climates.</p>
        <p>We are coordinating weekly volunteer shifts to repair collapsed sections of the paths leading to the high pastures. This physical, outdoor preservation work is a fantastic way to connect with the landscape and learn a ancient, sustainable craft.</p>
      `
    },
    author: 1,
    featured_media: 206,
    categories: [1],
    tags: [15],
    _embedded: {
      author: [{ id: 1, name: "Jean-Pierre Sere" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Beautiful steep mountain trail in the Pyrenees with dry stone border"
      }],
      'wp:term': [[
        { id: 1, name: "Heritage Preservation", slug: "preservation", taxonomy: "category" }
      ], [
        { id: 15, name: "Dry-stone", slug: "stone", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 107,
    date: "2025-09-02T10:45:00",
    slug: "the-art-of-the-pyrenean-weaver",
    title: { rendered: "The Art of the Pyrenean Weaver: Surving Techniques" },
    excerpt: { rendered: "<p>Exploring the hand-weaving and wool processing techniques that have survived for over five centuries in our isolated valleys.</p>" },
    content: {
      rendered: `
        <p>Isolated by high passes, the inhabitants of the Aure Valley historically had to produce their own textiles. Wool, harvested from local Aure-and-Campan sheep, was spun, dyed, and woven into durable blankets, capes, and clothing designed to withstand severe mountain winters. GPC65 recently visited one of the last remaining active weaving workshops in the region to document this precious craft.</p>
        
        <h3>From Fleece to Loom</h3>
        <p>Traditional Pyrenean weaving is a slow, laborious process requiring deep understanding of organic materials:</p>
        <ul>
          <li><strong>Vegetal Dyeing:</strong> Local wool artisans use extracts from wild madder roots, walnut husks, and weld plants to create warm reds, earthy browns, and rich yellows.</li>
          <li><strong>The Horizontal Loom:</strong> Large oak looms, some dating back to the 1800s, are hand-operated using foot pedals to create complex twill and chevron patterns.</li>
          <li><strong>Fulling:</strong> After weaving, the fabric is washed and beaten in mountain streams to compact the fibers, rendering it windproof and water-resistant.</li>
        </ul>

        <p>GPC65 is partnering with local weavers to establish a apprenticeship program, ensuring that younger generations learn to operate these historic looms and preserve the rich textile vocabulary of our ancestors.</p>
      `
    },
    author: 3,
    featured_media: 207,
    categories: [3],
    tags: [12],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Handmade wool textile close-up showing intricate loom pattern"
      }],
      'wp:term': [[
        { id: 3, name: "Culture & Art", slug: "culture", taxonomy: "category" }
      ], [
        { id: 12, name: "Weaving", slug: "weaving", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 108,
    date: "2025-08-20T14:15:00",
    slug: "village-revitalization-project-stage-2",
    title: { rendered: "Village Revitalization Project: Stage 2 Funding" },
    excerpt: { rendered: "<p>The association has successfully secured regional funding for the second phase of the urban heritage preservation plan in the old quarter.</p>" },
    content: {
      rendered: `
        <p>We are delighted to announce that the GPC65 Cultural Heritage Association, in coordination with the municipality of Cadéac, has been awarded a major regional development grant. This funding will support <strong>Stage 2 of the Old Quarter Revitalization Project</strong>, which aims to preserve public streets and historical details while updating utilities for modern living.</p>
        
        <h3>Scope of Works</h3>
        <p>The second phase of the project focuses on two key historical areas:</p>
        <ol>
          <li><strong>Pebble Paving Restoration:</strong> Restoring traditional river-pebble pavement (<em>calades</em>) on the steep pedestrian lanes. These lanes allow rainwater to flow safely down the slopes without causing erosion.</li>
          <li><strong>Historical Signage:</strong> Installing hand-painted enamel plaques detailing the architectural and social history of twenty key locations, creating an informative, self-guided walking tour for visitors.</li>
        </ol>

        <p>Work is scheduled to begin in September, with minimal disruptions to local shops and residents. This project represents a major step forward in proving that heritage preservation can act as an engine for local economy and community pride.</p>
      `
    },
    author: 3,
    featured_media: 208,
    categories: [1],
    tags: [15],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&w=1200&q=80",
        alt_text: "French mountain village street with stone houses and flowers"
      }],
      'wp:term': [[
        { id: 1, name: "Heritage Preservation", slug: "preservation", taxonomy: "category" }
      ], [
        { id: 15, name: "Dry-stone", slug: "stone", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 109,
    date: "2025-08-05T09:30:00",
    slug: "new-archaeological-findings-in-cerdanya",
    title: { rendered: "New Archaeological Findings in the Cerdanya Region" },
    excerpt: { rendered: "<p>Recent digs have revealed unexpected Roman settlement foundations that pre-date our current understanding of regional trade routes.</p>" },
    content: {
      rendered: `
        <p>While Cadéac remains the primary focus of GPC65, our researchers often collaborate with archeological teams across the Pyrenees. Last month, our field experts traveled to the Cerdanya plateau to assist in an emergency excavation of a site discovered during farm terracing. The findings have sent shockwaves through the local scientific community.</p>
        
        <h3>An Unrecorded Roman Station</h3>
        <p>The excavation revealed the foundations of a substantial Roman compound, consisting of a central courtyard, a fortified storehouse, and animal stables. Based on ceramic fragments (Samian ware) and metal implements recovered from the site, archaeologists estimate the site was occupied between 50 BC and 250 AD.</p>
        <p>The size of the storehouse suggests this was not a simple farm, but a regional collection depot for mountain commodities—most likely cheese, dried meats, timber, and iron—destined for Roman cities along the Mediterranean coast.</p>
      `
    },
    author: 2,
    featured_media: 209,
    categories: [2],
    tags: [],
    _embedded: {
      author: [{ id: 2, name: "Dr. Clara Montagne" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Historical archeological brick ruins in Pyrenean fields"
      }],
      'wp:term': [[
        { id: 2, name: "Archaeology", slug: "archaeology", taxonomy: "category" }
      ], []]
    }
  },
  {
    id: 110,
    date: "2025-07-22T21:00:00",
    slug: "celebrating-the-summer-solstice-traditions",
    title: { rendered: "Celebrating the Summer Solstice Traditions" },
    excerpt: { rendered: "<p>A photo essay and historical analysis of the traditional mountain fires and communal feasts that have marked the solstice for centuries.</p>" },
    content: {
      rendered: `
        <p>In the Pyrenees, the celebration of the <strong>Summer Solstice</strong> (<em>La Saint-Jean</em>) is more than a holiday—it is a deeply rooted ritual that has bound communities together for generations. Last month, the GPC65 Cultural Association co-organized the traditional beacon lighting on the heights above Cadéac, celebrating a heritage recognized by UNESCO.</p>
        
        <h3>The Fire of the Peak</h3>
        <p>At dusk, as the sun dipped behind the jagged peaks, volunteers ignited a massive wooden stack built on the high ridge. This fire was answered by distant pinpricks of light from fires lit on neighboring peaks, creating a spectacular chain of light across the Pyrenean horizon.</p>
        <p>Historically, these fires had a profound protective meaning: they symbolized the sun remaining at its highest strength, warding off agricultural pests, crop diseases, and storms for the coming harvest season.</p>
        
        <h3>Communal Feasting</h3>
        <p>The peak-lighting was followed by traditional music and dancing in the village square. Musicians playing traditional Pyrenean instruments, including the <em>chicotén</em> (stringed drum) and the vertical flute, kept the village dancing until dawn. GPC65 has compiled a photo archive of this year's festival, which is now available for viewing in the municipal library.</p>
      `
    },
    author: 3,
    featured_media: 210,
    categories: [3],
    tags: [14],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1533240332313-0db49b439ad3?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Huge outdoor bonfire burning bright at night"
      }],
      'wp:term': [[
        { id: 3, name: "Culture & Art", slug: "culture", taxonomy: "category" }
      ], [
        { id: 14, name: "Solstice", slug: "solstice", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 111,
    date: "2025-07-10T11:00:00",
    slug: "3d-scanning-for-heritage-preservation",
    title: { rendered: "3D Scanning for Heritage Preservation" },
    excerpt: { rendered: "<p>How we are using advanced LiDAR and photogrammetry to create immortal digital twins of crumbling high-mountain fortifications.</p>" },
    content: {
      rendered: `
        <p>Some of the valley's most fascinating historical structures are located in remote, inaccessible high-mountain passes. Reaching these sites is difficult, making physical preservation works incredibly costly. To address this, the GPC65 Technical Unit has turned to cutting-edge technology: <strong>3D LiDAR scanning and photogrammetry</strong>.</p>
        
        <h3>Creating Digital Twins</h3>
        <p>Using portable laser scanners and high-resolution camera drones, our technical team has begun scanning the ruins of several medieval sheepfolds and mountain forts. This process produces "point clouds" containing millions of highly accurate 3D coordinates, which are then processed into photorealistic, interactive 3D models.</p>
        <p>These digital twins allow historians and architects to inspect fragile stone structures from their desktops, track architectural decay over winter seasons, and plan targeted conservation efforts before a wall collapses.</p>
      `
    },
    author: 3,
    featured_media: 211,
    categories: [4],
    tags: [13],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1506318137071-a8e063b4bec0?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Laser point cloud visualization or high-tech optical equipment"
      }],
      'wp:term': [[
        { id: 4, name: "Community", slug: "community", taxonomy: "category" }
      ], [
        { id: 13, name: "Digital Mapping", slug: "mapping", taxonomy: "post_tag" }
      ]]
    }
  },
  {
    id: 112,
    date: "2025-06-25T14:00:00",
    slug: "the-tools-that-shaped-the-valley",
    title: { rendered: "The Tools That Shaped the Valley" },
    excerpt: { rendered: "<p>A curated exhibition focusing on the evolution of agricultural implements and their impact on the Pyrenean landscape.</p>" },
    content: {
      rendered: `
        <p>The landscapes of Cadéac—the dry-stone terraces, the irrigation channels (<em>biefs</em>), and the clear-cut high pastures—are not entirely natural; they are the result of centuries of agricultural labor. This month, GPC65 has curated a temporary exhibition titled <strong>"The Tools That Shaped the Valley"</strong> in the local museum annex.</p>
        
        <h3>Technology of the Mountain Farmer</h3>
        <p>The exhibition showcases over fifty historical tools, ranging from the late Middle Ages to the early 20th century. Key highlights include:</p>
        <ul>
          <li><strong>The Pyrenean Scythe:</strong> Specially balanced for mowing steep slopes, these scythes were manufactured with hard iron that required frequent rhythmic hammering (<em>battage</em>) in the fields.</li>
          <li><strong>Wooden Pack Saddles:</strong> Ingenious harness structures designed for donkeys and mules to transport hay, firewood, and cheeses down steep, narrow mountain tracks.</li>
          <li><strong>The Sluice Gate Spade:</strong> A heavy wrought-iron spade used to manage the communal irrigation channels, ensuring water was distributed fairly among valley farms.</li>
        </ul>

        <p>By understanding the physical tools used by our ancestors, we gain a profound respect for the extreme labor that sculpted our beautiful mountain heritage.</p>
      `
    },
    author: 3,
    featured_media: 212,
    categories: [3],
    tags: [],
    _embedded: {
      author: [{ id: 3, name: "GPC65 Editorial Team" }],
      'wp:featuredmedia': [{
        source_url: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&w=1200&q=80",
        alt_text: "Vintage wooden farming implements inside a rustic stone barn"
      }],
      'wp:term': [[
        { id: 3, name: "Culture & Art", slug: "culture", taxonomy: "category" }
      ], []]
    }
  }
];

// Helper to simplify WPPost to SimplifiedPost
export function simplifyPost(post: WPPost): SimplifiedPost {
  const authorName = post._embedded?.author?.[0]?.name || "GPC65 Contributor";
  const featuredImageUrl = post._embedded?.['wp:featuredmedia']?.[0]?.source_url || 
                           "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=80"; // Default Pyrenees landscape

  const categories = post._embedded?.['wp:term']?.[0]?.map(cat => ({
    id: cat.id,
    name: cat.name,
    slug: cat.slug
  })) || [];

  const tags = post._embedded?.['wp:term']?.[1]?.map(tag => ({
    id: tag.id,
    name: tag.name,
    slug: tag.slug
  })) || [];

  return {
    id: post.id,
    slug: post.slug,
    title: post.title.rendered,
    content: post.content.rendered,
    excerpt: post.excerpt.rendered.replace(/<[^>]*>/g, '').substring(0, 160) + "...",
    date: post.date,
    authorName,
    featuredImageUrl,
    categories,
    tags
  };
}

// In-memory cache
const cache = {
  posts: null as WPPost[] | null,
  categories: null as WPCategory[] | null,
  tags: null as WPTag[] | null,
  lastFetched: 0
};

const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

async function fetchWithTimeout(url: string, options: RequestInit = {}, timeout = 5000): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}

export async function getPosts(forceRefresh = false): Promise<WPPost[]> {
  const now = Date.now();
  if (!forceRefresh && cache.posts && (now - cache.lastFetched < CACHE_DURATION)) {
    return cache.posts;
  }

  try {
    const res = await fetchWithTimeout(`${WP_API_BASE}/posts?_embed=true&per_page=50`, {}, 4000);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) {
      cache.posts = data;
      cache.lastFetched = now;
      return data;
    }
    throw new Error("Empty posts array from API");
  } catch (err) {
    console.warn("GPC65: Falling back to seed historical database for posts due to connection error:", err);
    // Return sorted by date descending
    const sortedSeed = [...SEED_POSTS].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    cache.posts = sortedSeed;
    return sortedSeed;
  }
}

export async function getCategories(forceRefresh = false): Promise<WPCategory[]> {
  const now = Date.now();
  if (!forceRefresh && cache.categories) return cache.categories;

  try {
    const res = await fetchWithTimeout(`${WP_API_BASE}/categories?per_page=50`, {}, 4000);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) {
      cache.categories = data;
      return data;
    }
    throw new Error("Empty categories array from API");
  } catch (err) {
    console.warn("GPC65: Falling back to seed categories:", err);
    cache.categories = SEED_CATEGORIES;
    return SEED_CATEGORIES;
  }
}

export async function getTags(forceRefresh = false): Promise<WPTag[]> {
  const now = Date.now();
  if (!forceRefresh && cache.tags) return cache.tags;

  try {
    const res = await fetchWithTimeout(`${WP_API_BASE}/tags?per_page=100`, {}, 4000);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) {
      cache.tags = data;
      return data;
    }
    throw new Error("Empty tags array from API");
  } catch (err) {
    console.warn("GPC65: Falling back to seed tags:", err);
    cache.tags = SEED_TAGS;
    return SEED_TAGS;
  }
}

export async function getPostBySlug(slug: string): Promise<WPPost | null> {
  const posts = await getPosts();
  const found = posts.find(p => p.slug === slug);
  if (found) return found;

  // Try API specifically for slug
  try {
    const res = await fetchWithTimeout(`${WP_API_BASE}/posts?_embed=true&slug=${encodeURIComponent(slug)}`, {}, 3000);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        return data[0];
      }
    }
  } catch (err) {
    console.error(`GPC65: Could not fetch post by slug '${slug}' from API:`, err);
  }

  return null;
}
